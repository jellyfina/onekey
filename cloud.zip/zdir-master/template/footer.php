<!-- 底部 -->
 	<div class = "footer">
		<div class = "layui-container">
			<div class = "layui-row">
				<div class = "layui-col-lg12">
				Copyright © 2017-2021 Powered by <a href="https://t.me/jellyfina" target = "_blank">jellyfin</a>
				</div>
			</div>
		</div>
	</div>
	<!-- 底部END -->
	
	<!--遍历目录END-->
	<script type="text/javascript" src = "./static/jquery.min.js"></script>
	<script src = './static/zdir.js'></script>
	<script type="text/javascript" src="./static/layui/layui.js"></script>
	<script type="text/javascript" src="./static/qrcode.min.js"></script>
	<script type="text/javascript" src="./static/embed.js?v=<?php echo $version; ?>"></script>
	<script type="text/javascript" src="./static/clipBoard.min.js"></script>
</body>
</html>
